


*By submitting this Contribution you hereby grant to Chris Gamble a worldwide, royalty-free, non-exclusive, perpetual and irrevocable license, with the right to transfer an unlimited number of non-exclusive licenses or to grant sublicenses to third parties, under the Copyright covering the Contribution to use the Contribution by all means, including, but not limited to: publish the Contribution, modify the Contribution, prepare derivative works based upon or containing the Contribution and/or to combine the Contribution with other Materials, reproduce the Contribution in original or modified form, distribute, to make the Contribution available to the public, display and publicly perform the Contribution in original or modified form.*
